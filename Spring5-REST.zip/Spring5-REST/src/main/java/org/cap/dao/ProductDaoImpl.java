package org.cap.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.cap.model.Product;
import org.springframework.stereotype.Repository;
@Repository("productDao")
public class ProductDaoImpl implements IProductDao{
	
	private static AtomicInteger productId=new AtomicInteger(10000);
	private static List<Product> products=getDummyDB();
	
	private static List<Product> getDummyDB(){
		List<Product> products=new ArrayList<>();
		
		products.add(new Product(productId.incrementAndGet(), "Sony Xperia", 5, 45000, new Date(2001-1900, 3, 21)));
		products.add(new Product(productId.incrementAndGet(), "IPhone xs", 5, 145000, new Date(2012-1900, 1, 11)));
		products.add(new Product(productId.incrementAndGet(), "Samsung Xperia", 15, 12000, new Date(1991-1900, 4, 11)));
		products.add(new Product(productId.incrementAndGet(), "Iphone-8", 2, 105000, new Date(1990-1900, 10, 1)));
		products.add(new Product(productId.incrementAndGet(), "SonyXperia ZL", 15, 35000, new Date(2001-1900, 9, 2)));
		return products;
		
	}

	@Override
	public List<Product> getAllProducts() {
		
		return products;
	}

	@Override
	public Product findProduct(int productId) {
		for(Product product:products) {
			if(product.getProductId()==productId){
				return product;
			}
		}
		return null;
	}

	@Override
	public List<Product> deleteProduct(int productId) {
		boolean flag=false;
		Iterator<Product> iterator= products.iterator();
		while(iterator.hasNext()) {
			Product product= iterator.next();
			if(product.getProductId()==productId) {
				flag=true;
				iterator.remove();
				break;
			}
		}
		if(flag)
			return products;
		else
			return null;
	}

	@Override
	public List<Product> createProduct(Product product) {
		products.add(product);
		return products;
	}

	
	
}
