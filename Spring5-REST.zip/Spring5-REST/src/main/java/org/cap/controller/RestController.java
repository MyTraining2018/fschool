package org.cap.controller;

import java.util.List;

import org.cap.dao.IProductDao;
import org.cap.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

@org.springframework.web.bind.annotation.RestController
@RequestMapping("/product/api/v1")
public class RestController {
	
	@Autowired
	private IProductDao productDao;
	
	@PostMapping("/products")
	public ResponseEntity<List<Product>> createProduct(
			@RequestBody Product product){
		
		List<Product> products= productDao.createProduct(product);
		if(products.isEmpty()) {
			return new ResponseEntity("Sorry! Product Not avaliable!",
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Product>>(products,HttpStatus.OK);
	}
	
	
	
	
	
	
	
	
	@DeleteMapping("/products/{productId}")
	public ResponseEntity<List<Product>> deleteProduct(
			@PathVariable("productId")Integer productId){
		List<Product> products= productDao.deleteProduct(productId);
		
		if(products==null) {
			return new ResponseEntity("Sorry! Product ID Not avaliable!",
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Product>>(products,HttpStatus.OK);
	}
	
	
	
	
	
	
	
	
	
	
	
	@GetMapping("/products/{productId}")
	public ResponseEntity<Product> findProduct(
			@PathVariable("productId")Integer productId){
		Product product= productDao.findProduct(productId);
		
		if(product==null) {
			return new ResponseEntity("Sorry! ProductID Not Found!",
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<Product>(product,HttpStatus.OK);
	}
	
	@GetMapping("/products")
	public ResponseEntity<List<Product>> getAllProducts(){
		List<Product> products= productDao.getAllProducts();
		
		if(products.isEmpty()) {
			return new ResponseEntity("Sorry! Products Not avaliable!",
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Product>>(products,HttpStatus.OK);
	}
	
	

	@RequestMapping("/hello")
	public String sayHello() {
		return "Hello world! from Spring RestController";
	}
	
	
}
