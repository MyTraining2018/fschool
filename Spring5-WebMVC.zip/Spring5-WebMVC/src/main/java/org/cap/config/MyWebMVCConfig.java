package org.cap.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;

@Configuration
@EnableWebMvc
@ComponentScan("org.cap")
@EnableTransactionManagement
public class MyWebMVCConfig {

	@Bean
	public ViewResolver getViewResolverBean() {
		InternalResourceViewResolver resolver=new InternalResourceViewResolver();
		resolver.setPrefix("/WEB-INF/jsp/");
		resolver.setSuffix(".jsp");
		resolver.setViewClass(JstlView.class);
		return resolver;
	}
	
	@Bean
	public LocalContainerEntityManagerFactoryBean getEntityMangerFactoryBean() {
		LocalContainerEntityManagerFactoryBean emf=
				new LocalContainerEntityManagerFactoryBean();
		emf.setPersistenceUnitName("jpademo");
		return emf;
	}
	
	@Bean
	public JpaTransactionManager getTransactionManagerBean() {
		JpaTransactionManager transactionManager=
				new JpaTransactionManager(getEntityMangerFactoryBean().getObject());
		return transactionManager;
	}
	
	
}
