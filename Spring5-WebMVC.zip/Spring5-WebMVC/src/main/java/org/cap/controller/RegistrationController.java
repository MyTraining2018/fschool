package org.cap.controller;

import java.util.ArrayList;
import java.util.List;

import org.cap.model.Registration;
import org.cap.service.IRegistrationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class RegistrationController {
	
	@Autowired
	private IRegistrationService registerService;
	
	
	@RequestMapping(value="/saveRegistration",method=RequestMethod.POST)
	public String saveAllRegistration(
			@ModelAttribute("register") Registration registration) {
		
		registerService.saveRegistration(registration);
		
		return "success";
	}
	
	public List<String> getCities(){
		List<String> cities=new ArrayList<>();
		cities.add("Chennai");
		cities.add("Pune");
		cities.add("Mumbai");
		cities.add("Hyderabad");
		cities.add("Cochin");
		cities.add("Bangalore");
		cities.add("Kolkatta");
		
		
		return cities;
	}

	@RequestMapping("/register")
	public String getRegistrationPage(ModelMap map) {
		
		
		
		map.put("register",new Registration());
		map.put("cities", getCities());
		
		//return new ModelAndView("register","register",new Registration());
		return "register";
	}
	
}
