package org.cap.service;

import org.cap.dao.IRegisterDao;
import org.cap.model.Registration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("registerService")
public class RegistrationServiceImpl implements IRegistrationService {
	
	@Autowired
	private IRegisterDao registerDao;

	@Override
	public void saveRegistration(Registration registration) {
		registerDao.saveRegistration(registration);
		
	}

}
