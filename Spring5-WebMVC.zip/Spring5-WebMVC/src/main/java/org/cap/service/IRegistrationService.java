package org.cap.service;

import org.cap.model.Registration;

public interface IRegistrationService {
	public void saveRegistration(Registration registration);
}
