package org.cap.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.cap.model.Registration;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("registerDao")
@Transactional
public class RegistrationDaoImpl implements IRegisterDao{
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void saveRegistration(Registration registration) {
		entityManager.persist(registration);
		
	}

}
