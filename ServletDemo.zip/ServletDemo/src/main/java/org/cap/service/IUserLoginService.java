package org.cap.service;

import org.cap.model.UserLogin;

public interface IUserLoginService {
	public boolean isValidUser(UserLogin login);

}
