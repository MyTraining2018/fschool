package org.cap.service;

import org.cap.model.UserLogin;

public class UserLoginServiceImpl implements IUserLoginService {

	@Override
	public boolean isValidUser(UserLogin login) {
		if(login.getUserName().equals("tom") &&
				login.getUserPassword().equals("tom123") )
			return true;
		return false;
	}

}
