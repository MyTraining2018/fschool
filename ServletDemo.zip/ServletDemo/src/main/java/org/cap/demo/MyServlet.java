package org.cap.demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(value="/MyServlet",initParams= {
		@WebInitParam(name="email",value="capg@info.com")
})
public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
		private String color;
       private String myemail;
  
	@Override
	public void init(ServletConfig config) throws ServletException {
		
		System.out.println("Servlet Initialized!");
		myemail=config.getInitParameter("email");
		color=config.getServletContext().getInitParameter("color");
		
	}




	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
				throws ServletException, IOException {
		System.out.println("Servlet Service!");
		PrintWriter out= response.getWriter();
		out.println("<h1>Welcome to Servlet3!</h1>");
		out.println("<h3>Email:" + myemail +"</h3>");
		out.println("<h3>Color:" + color +"</h3>");
		
	}




	@Override
	public void destroy() {
		System.out.println("Servlet Destroyed..................");
	}
	
	
	
	

}
