package org.cap.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.model.UserLogin;
import org.cap.service.IUserLoginService;
import org.cap.service.UserLoginServiceImpl;

@WebServlet("/ValidateLogin")
public class ValidateLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private IUserLoginService loginService;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		loginService=new UserLoginServiceImpl();
		String userName=request.getParameter("userName");
		String userPwd=request.getParameter("userPwd");
		String email=request.getParameter("email");
		
		System.out.println(email);
		
		UserLogin login=new UserLogin(userName, userPwd);
		
		
		if(loginService.isValidUser(login)) {
			//response.sendRedirect("pages/mainPage.html");
			request.getRequestDispatcher("pages/mainPage.html")
				.forward(request, response);
		}else {
			response.sendRedirect("index.html");
		}
		
	}

}
