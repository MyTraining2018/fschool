package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.cap.model.UserLogin;
import org.springframework.stereotype.Repository;

@Repository("loginDao")
@Transactional
public class LoginDaoImpl implements ILoginDao{

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public boolean validateLogin(UserLogin userLogin) {
		String sql="from UserLogin user where user.userName=:uname "
				+ "and user.userPassword=:upwd";
		Query query=entityManager.createQuery(sql);
		query.setParameter("uname", userLogin.getUserName());
		query.setParameter("upwd", userLogin.getUserPassword());
		
		List<UserLogin> logins= query.getResultList();
		if(logins.size()>0)
			return true;
		
		return false;
	}

}
