package org.cap.dao;

import org.cap.model.UserLogin;

public interface ILoginDao {
	public boolean validateLogin(UserLogin userLogin);
}
