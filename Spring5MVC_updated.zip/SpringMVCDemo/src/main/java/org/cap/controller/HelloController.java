package org.cap.controller;

import org.cap.model.UserLogin;
import org.cap.service.ILoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloController {

	@Autowired
	private ILoginService loginService;
	
	@RequestMapping("/validateLogin")
	public String validateLogin(
			@RequestParam("userName")String userName,
			@RequestParam("userPwd")String userPwd) {
		
		UserLogin userLogin=new UserLogin();
		userLogin.setUserName(userName);
		userLogin.setUserPassword(userPwd);
		if(loginService.validateLogin(userLogin)) {
			return "success";
		}
		
		return "redirect:/";
	}
	
	@RequestMapping("/hello")
	public ModelAndView sayHello() {
		return new ModelAndView("helloPage","message","Hello! Welcome!"); 
	}
}
