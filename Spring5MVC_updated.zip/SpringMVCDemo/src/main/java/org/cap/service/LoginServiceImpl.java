package org.cap.service;

import org.cap.dao.ILoginDao;
import org.cap.model.UserLogin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("loginService")
public class LoginServiceImpl implements ILoginService{
	
	@Autowired
	private ILoginDao loginDao;

	@Override
	public boolean validateLogin(UserLogin userLogin) {
		/*if(userLogin.getUserName().equals("tom") && 
				userLogin.getUserPassword().equals("tom123"))
			return true;*/
		
		
		return loginDao.validateLogin(userLogin);
	}

}
