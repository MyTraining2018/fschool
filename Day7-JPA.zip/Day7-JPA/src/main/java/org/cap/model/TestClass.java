package org.cap.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TestClass {

	public static void main(String[] args) {
		EntityManagerFactory emf=
				Persistence.createEntityManagerFactory("jpademo");
		
		EntityManager entityManager= emf.createEntityManager();
		EntityTransaction transaction= entityManager.getTransaction();
		
		transaction.begin();
		
		Company capg=new Company();
		capg.setCompanyId(1001);
		capg.setCompanyName("Capgemini Consulting Services");
		
		Company tcs=new Company();
		tcs.setCompanyId(1009);
		tcs.setCompanyName("TATA Consultancy Services");
		
			Employee tom=new Employee();
			tom.setFirstName("Tom");
			tom.setLastName("Jerry");
			tom.setDateOfBirth(LocalDate.of(1991, 3, 10));
			tom.setEmail("tom@gmail.com");
			tom.setEmpPassword("tom12345");
			tom.setLoginTime(new Date());
			tom.setSalary(67000);
			tom.setCompany(capg);
			
			
			Employee paul=new Employee();
			paul.setFirstName("Paul");
			paul.setLastName("Thomson");
			paul.setDateOfBirth(LocalDate.of(1991, 3, 10));
			paul.setEmail("paul@gmail.com");
			paul.setEmpPassword("paul12345");
			paul.setLoginTime(new Date());
			paul.setSalary(67000);
			paul.setCompany(capg);
			
			
			Employee jack=new Employee();
			jack.setFirstName("jack");
			jack.setLastName("Emison");
			jack.setDateOfBirth(LocalDate.of(1991, 3, 10));
			jack.setEmail("jack@gmail.com");
			jack.setEmpPassword("jack12345");
			jack.setLoginTime(new Date());
			jack.setSalary(67000);
			jack.setCompany(tcs);
			
			//insert the object into relation
			entityManager.persist(tom);
			entityManager.persist(paul);
			entityManager.persist(jack);
			
			entityManager.persist(capg);
			entityManager.persist(tcs);
			
		transaction.commit();
		entityManager.close();
		
	}

}
