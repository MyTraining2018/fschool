package org.cap.manytomany;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TestClass {

	public static void main(String[] args) {
		EntityManagerFactory emf=
				Persistence.createEntityManagerFactory("jpademo");
		
		EntityManager entityManager= emf.createEntityManager();
		EntityTransaction transaction= entityManager.getTransaction();
		
		transaction.begin();
		
			Event java=new Event();
			java.setEventId(1001);
			java.setEventName("JAVA_1001");
			
			Event oracle=new Event();
			oracle.setEventId(1003);
			oracle.setEventName("ORACLE_1003");
		
		
			Event net=new Event();
			net.setEventId(1005);
			net.setEventName("NET_1003");
			
			
			Delegate tom=new Delegate(1, "tom");
			Delegate jerry=new Delegate(2, "Jerry");
			Delegate paul=new Delegate(3, "Paul");
			
			tom.getEvents().add(java);
			tom.getEvents().add(oracle);
			jerry.getEvents().add(net);
			paul.getEvents().add(net);
			paul.getEvents().add(java);
			paul.getEvents().add(oracle);
		
			
			entityManager.persist(paul);
			entityManager.persist(tom);
			entityManager.persist(jerry);
			
			entityManager.persist(java);
			entityManager.persist(oracle);
			entityManager.persist(net);
			
		transaction.commit();
	}

}
