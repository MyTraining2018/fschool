package org.cap.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name="FirstServlet",urlPatterns= {"/FirstServlet","/hello"},
		initParams= {@WebInitParam(name="email",value="info@capgemini.com"),
				@WebInitParam(name="color",value="green")})
public class FirstServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private String email,color,url;
	public void init(ServletConfig config) throws ServletException {
		
		ServletContext context= config.getServletContext();
		url=context.getInitParameter("url");
		email=config.getInitParameter("email");
		color=config.getInitParameter("color");
		System.out.println("FirstServlet Initialized.........");
	}

	
	public void destroy() {
		System.out.println("FirstServlet Destroyed.........");
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		System.out.println("FirstServlet Service.........");
		out.println("<h1>Hello! Welcome to Servlets!</h1>");
		out.println("<h3>Email: " + email+"</h3>");
		out.println("<h3>Color: " + color+"</h3>");
		out.println("<h3>URL: " + url+"</h3>");
	}

}
