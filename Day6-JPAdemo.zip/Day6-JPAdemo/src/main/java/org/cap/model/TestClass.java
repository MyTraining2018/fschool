package org.cap.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TestClass {

	public static void main(String[] args) {
		EntityManagerFactory emf=
				Persistence.createEntityManagerFactory("jpademo");
		
		EntityManager entityManager= emf.createEntityManager();
		EntityTransaction transaction= entityManager.getTransaction();
		
		transaction.begin();
			Employee tom=new Employee(1001, "Tom", "Jerry", 23000, "tom@gmail.com", LocalDateTime.of(1991, 3, 12,9,23));
			//insert the object into relation
			entityManager.persist(tom);
		
		transaction.commit();
		entityManager.close();
		
	}

}
