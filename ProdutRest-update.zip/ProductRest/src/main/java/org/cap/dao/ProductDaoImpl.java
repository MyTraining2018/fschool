package org.cap.dao;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.cap.model.Product;
import org.springframework.stereotype.Repository;

@Repository("productDao")
public class ProductDaoImpl implements IProductDao{
	private static AtomicInteger productId=new AtomicInteger(10000);
	private static List<Product> products=getDummyDb();
	
	private static List<Product> getDummyDb(){
		List<Product> products=new ArrayList<>();
		/*products.add(new Product(productId.incrementAndGet(), "Sony ZL", 3, 35000, new Date(2021-1900, 2, 3)));
		products.add(new Product(productId.incrementAndGet(), "Iphone xs", 12, 150000, new Date(2029-1900, 2, 3)));
		products.add(new Product(productId.incrementAndGet(), "Honor 8x", 34, 23000, new Date(2034-1900, 2, 3)));
		products.add(new Product(productId.incrementAndGet(), "redmi", 8, 13000, new Date(2019-1900, 2, 3)));
		*/
		products.add(new Product(productId.incrementAndGet(), "Sony ZL", 3, 35000, LocalDate.of(2021, 2, 3)));
		products.add(new Product(productId.incrementAndGet(), "Iphone xs", 12, 150000, LocalDate.of(2029, 2, 3)));
		products.add(new Product(productId.incrementAndGet(), "Honor 8x", 34, 23000, LocalDate.of(2034, 2, 3)));
		products.add(new Product(productId.incrementAndGet(), "redmi", 8, 13000, LocalDate.of(2019, 2, 3)));
		
		
		return products;
	}
	

	@Override
	public List<Product> getAllProducts() {
		return products;
	}


	@Override
	public Product findProduct(Integer productId) {
		for(Product product:products) {
			if(productId==product.getProductId()) {
				return product;
			}
		}
		return null;
	}


	@Override
	public List<Product> deleteProduct(Integer productId) {
		boolean flag=false;
		
		Iterator<Product> iterator= products.iterator();
		while(iterator.hasNext()) {
			Product product= iterator.next();
			if(product.getProductId()==productId) {
				flag=true;
				iterator.remove();
				break;
			}
		}
		if(flag)
			return products;
		else
			return null;
	}


	@Override
	public List<Product> saveProduct(Product product) {
		products.add(product);
		return products;
	}

}
