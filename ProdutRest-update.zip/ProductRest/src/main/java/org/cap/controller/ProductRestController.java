package org.cap.controller;

import java.util.List;

import org.cap.dao.IProductDao;
import org.cap.model.Product;
import org.cap.service.IProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonFormat;

@RestController
@RequestMapping("/api/v1")
public class ProductRestController {
	
	@Autowired
	private IProductService productService;
	
	
	@PutMapping("/products")
	public ResponseEntity<List<Product>> updateProduct(
			@RequestBody Product product){
		
		List<Product> products= productService.saveProduct(product);
		
		if(products.isEmpty())
			return new ResponseEntity
					("Sorry! Insertion Failed!", HttpStatus.BAD_REQUEST);
		
		return new ResponseEntity<List<Product>>(products, HttpStatus.CREATED);
	}
	
	
	
	@PostMapping("/products")
	public ResponseEntity<List<Product>> createProduct(
			@DateTimeFormat(iso=DateTimeFormat.ISO.DATE_TIME) 
			@RequestBody Product product){
		
		List<Product> products= productService.saveProduct(product);
		
		if(products.isEmpty())
			return new ResponseEntity
					("Sorry! Insertion Failed!", HttpStatus.BAD_REQUEST);
		
		return new ResponseEntity<List<Product>>(products, HttpStatus.CREATED);
	}
	
	
	
	
	@DeleteMapping("/products/{productId}")
	public ResponseEntity<List<Product>> deleteProducts(
			@PathVariable("productId") Integer productId){
		
		List<Product> products= productService.deleteProduct(productId);
		
		if(products==null)
			return new ResponseEntity
						("Sorry! Product ID Not Available!", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}
	
	
	@GetMapping("/products/{productId}")
	@DateTimeFormat(iso=DateTimeFormat.ISO.DATE)
	public ResponseEntity<Product> findProducts(
			@PathVariable("productId")Integer productId){
		
		
		Product product= productService.findProduct(productId);
		
		if(product==null)
			return new ResponseEntity
						("Sorry! ProductId Not Found!", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<Product>(product, HttpStatus.OK);
	}

	
	@GetMapping("/products")
	public ResponseEntity<List<Product>> getAllProducts(){
		
		List<Product> products= productService.getAllProducts();
		
		if(products.isEmpty())
			return new ResponseEntity
						("Sorry! Product details Not Available!", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}
	
}
